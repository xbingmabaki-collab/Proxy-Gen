import random
import time
import sys
import os
import shutil
from colorama import init, Fore, Style

init(autoreset=True)

def generate_random_ip():
    return ".".join(str(random.randint(1, 255)) for _ in range(4))

def generate_random_port():
    return str(random.randint(1024, 65535))

def generate_proxy():
    return f"{generate_random_ip()}:{generate_random_port()}"

filename = "proxy.txt"
if not os.path.exists(filename):
    with open(filename, "w") as f:
        pass

delay_ranges = {
    1: (0.1, 0.3),
    2: (0.5, 1),
    3: (1, 2),
    4: (2, 3),
    5: (3, 5),
    6: (4, 5),
    7: (5, 6.5),
    8: (7, 8.5),
    9: (9, 10),
    10: (12, 15)
}

ascii_art = [
    "                                     ____                     ",
    "      _ __  _ __ _____  ___   _   / ___| ___ _ __          ",
    "     | '_ \\| '__/ _ \\ \\/ / | | | |  _ / _ \\ '_ \\         ",
    "     | |_) | | | (_) >  <| |_| | | |_| |  __/ | | |       ",
    "     | .__/|_|  \\___/_/\\_\\\\__, |  \\____|\\___|_| |_|      ",
    "      |_|                   |___/                          "
]

colors = [Fore.RED, Fore.YELLOW, Fore.CYAN, Fore.GREEN, Fore.MAGENTA, Fore.BLUE]
term_width = shutil.get_terminal_size().columns

# 아스키 아트 출력
for line in ascii_art:
    color = random.choice(colors)
    print(color + line.center(term_width))

# made by 문구 출력 (랜덤 색상)
made_color = random.choice(colors)
print(made_color + "made: r1yx._jun1_".center(term_width))

start = input(Fore.LIGHTWHITE_EX + "\n처음에 프록시 생성을 시작하실건가요? (y/n): ").strip().lower()
if start == 'n':
    print(Fore.RED + "강제 종료합니다.")
    sys.exit()
elif start != 'y':
    print(Fore.RED + "잘못된 입력입니다. 강제 종료합니다.")
    sys.exit()

speed_input = input(Fore.LIGHTWHITE_EX + "속도를 1~10 사이의 숫자를 입력해주세요. 강제 종료합니다. (기본값: 2): ").strip()
if speed_input == "":
    speed = 2
elif not speed_input.isdigit() or '.' in speed_input:
    print(Fore.RED + "잘못된 입력입니다. 강제 종료합니다.")
    sys.exit()
else:
    speed = int(speed_input)
    if not 1 <= speed <= 10:
        print(Fore.RED + "1~10 사이의 숫자를 입력해주세요. 강제 종료합니다.")
        sys.exit()

min_delay, max_delay = delay_ranges[speed]

print(Fore.GREEN + "\n프록시 생성을 시작합니다... Ctrl+C로 종료 가능\n")

try:
    count = 0
    while True:
        proxy = generate_proxy()
        count += 1

        proxy_color = random.choice(colors)
        end_color = random.choice([c for c in colors if c != proxy_color])

        print(proxy_color + f"[{count}] {proxy}".center(term_width))
        print(end_color + "(Ctrl+C = end)".center(term_width))

        with open(filename, "a") as f:
            f.write(proxy + "\n")

        delay = random.uniform(min_delay, max_delay)
        time.sleep(delay)

except KeyboardInterrupt:
    print(Fore.YELLOW + "\n프로그램 종료")